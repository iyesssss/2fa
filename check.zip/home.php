<?php
if (!defined('ALLOWED')) {
    exit('Direct access not allowed!');
}

header('Cache-Control: no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: Wed, 11 Jan 1984 05:00:00 GMT');

echo <<<HTML
<!DOCTYPE html>
<html lang="en">

</html>
HTML;
?>
